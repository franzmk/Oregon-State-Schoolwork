Max Franz
franzmax@oregonstate.edu
10/20/20

Run this command to successfully compile my code:
gcc -std=gnu99 main.c -o movies_by_year
