To compile my code, type 'make'

TA, my code does not work as it is. It worked before I converted it into a multi-threaded system, but
as is stands this thing is a wreck. I thought I could figure out what was wrong, but I've spent
a few days going over my code and for the life of me I can't.
