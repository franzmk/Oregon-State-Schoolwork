Compile the program with this command:
gcc --std=gnu99 -o movies main.c
