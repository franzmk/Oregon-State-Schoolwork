To compile, type 'make'.
