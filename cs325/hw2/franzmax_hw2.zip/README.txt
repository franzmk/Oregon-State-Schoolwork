To compile code, type 'make'.
