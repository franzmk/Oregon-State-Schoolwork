To compile, type 'make'.
To execute, type './mst graph.txt'