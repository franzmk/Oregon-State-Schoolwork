To compile, type 'make'. This will compile all four programs.
