Max Franz - 10/27/20 - CS370

Part 1 of this assignment is located in the "Assignment1Report.pdf". This is also where the observations for 3.2 and 3.3 are.

Part 2 and 3 of this assignment have been separated into their own directories. Each directory has its own Makefile as well.
To compile, simply enter whichever directory and type "make". For 3.2, the executable is saved as "enc" for encryption. For
3.3, the executable is saved as "svw" for strong vs weak.