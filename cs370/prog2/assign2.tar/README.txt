I use this line to run my program:

python bloom_filter.py -d dictionary.txt -i input.txt -o output3.txt output5.txt

The order matters so that the right files are used for the right purpose.


