Maxwell Franz

This program creates a linked list and fills it with values through a do-while loop
using the push_back function until the user doesn't want to add anymore. After the user
enters 'n', it asks for two more values and puts them into the linked list using the
push_front function. It then asks for one more value and places it into the linked list
using the insert function and places it in the third index. It then asks the user if they
want to sort in ascending or descending order, does whichever they choose, and then prints
the list in sorted order and counts how many prime numbers there are. Then it deletes the
list and clears all memory. 
