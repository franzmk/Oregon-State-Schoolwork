#include "restaurant.h"

int main() {
	Restaurant r;
	r.load_data();
	r.start();

	return 0;
}
